package question_3;

public interface Wordcount {
	int count(String str);

}
