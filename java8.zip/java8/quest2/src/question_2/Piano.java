package question_2;

public interface Piano {
	public void play();

}
