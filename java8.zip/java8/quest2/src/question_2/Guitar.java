package question_2;

public interface Guitar {
	
	public void play();

}
