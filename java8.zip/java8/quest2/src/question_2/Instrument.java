package question_2;

public class Instrument implements Guitar,Piano{
	
	public void play() {      
		
		System.out.println(" Instrument is being played");
	}


}
